import { env, pipeline } from "@huggingface/transformers";

env.allowRemoteModels = true;
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = chrome.runtime.getURL("vendor/");
env.backends.onnx.wasm.numThreads = 1;

const DEFAULTS = {
  localTranscriptionModel: "onnx-community/whisper-tiny",
  localTranscriptionDevice: "auto",
  translationBaseUrl: "https://api.deepseek.com",
  translationApiKey: "",
  translationEndpoint: "",
  translationHeaders: "{}",
  translationModel: "deepseek-v4-flash",
  sourceLanguage: "auto",
  targetLanguage: "简体中文",
  chunkSeconds: 10,
  translationEnabled: true,
  showOriginal: true,
  fontSize: 24,
  subtitlePosition: "bottom",
  translationPrompt: ""
};

let captureStream = null;
let recorder = null;
let stopTimer = null;
let audioContext = null;
let stopped = true;
let targetTabId = null;
let targetTabTitle = "";
let sequence = 0;
let generation = 0;
let config = { ...DEFAULTS };
let uploadQueue = Promise.resolve();
let transcriber = null;
let loadedModelKey = "";
let inferenceDevice = "";
const webgpuFailedModels = new Set();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== "offscreen") return false;

  if (message.type === "START_CAPTURE") {
    startCapture(message)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        reportStatus("error", error.message);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message.type === "STOP_CAPTURE") {
    stopCapture().then(() => sendResponse({ ok: true }));
    return true;
  }

  return false;
});

async function startCapture({ streamId, tabId, tabTitle, config: suppliedConfig }) {
  await stopCapture(false);
  const captureGeneration = ++generation;
  // Offscreen 文档只能可靠访问 chrome.runtime，设置由 service worker 读取后传入。
  config = { ...DEFAULTS, ...(suppliedConfig || {}) };
  validateConfig(config);

  targetTabId = tabId;
  targetTabTitle = tabTitle;
  sequence = 0;
  uploadQueue = Promise.resolve();
  stopped = false;

  captureStream = await navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId
      }
    },
    video: false
  });

  // tabCapture 会暂时移除标签页的本地音频输出，这里重新连接，用户仍可听到视频声音。
  audioContext = new AudioContext();
  const source = audioContext.createMediaStreamSource(captureStream);
  source.connect(audioContext.destination);
  if (audioContext.state === "suspended") await audioContext.resume();

  reportStatus("starting", "正在加载本地 Whisper 模型，首次使用需要下载…");
  await ensureTranscriber(captureGeneration);
  if (stopped || captureGeneration !== generation) return;
  reportStatus("running", `本地 ${inferenceDevice.toUpperCase()} 转写中（约 ${config.chunkSeconds} 秒一段）`);
  recordNextChunk(captureGeneration);
}

async function stopCapture(report = true) {
  stopped = true;
  generation += 1;
  clearTimeout(stopTimer);
  stopTimer = null;

  if (recorder && recorder.state !== "inactive") {
    recorder.onstop = null;
    recorder.stop();
  }
  recorder = null;

  captureStream?.getTracks().forEach((track) => track.stop());
  captureStream = null;

  if (audioContext && audioContext.state !== "closed") await audioContext.close().catch(() => {});
  audioContext = null;

  if (report && targetTabId !== null) reportStatus("idle", "已停止");
  targetTabId = null;
  targetTabTitle = "";
}

function recordNextChunk(captureGeneration) {
  if (stopped || captureGeneration !== generation || !captureStream?.active) return;

  const mimeType = chooseMimeType();
  const options = { audioBitsPerSecond: 128000 };
  if (mimeType) options.mimeType = mimeType;

  const chunks = [];
  recorder = new MediaRecorder(captureStream, options);
  recorder.ondataavailable = (event) => {
    if (event.data?.size) chunks.push(event.data);
  };
  recorder.onerror = (event) => reportError(event.error?.message || "音频录制失败");
  recorder.onstop = () => {
    clearTimeout(stopTimer);
    const blob = new Blob(chunks, { type: recorder?.mimeType || mimeType || "audio/webm" });
    if (blob.size > 1024) enqueueAudio(blob, ++sequence, captureGeneration);
    if (!stopped && captureGeneration === generation) recordNextChunk(captureGeneration);
  };
  recorder.start();
  stopTimer = setTimeout(() => {
    if (recorder?.state === "recording") recorder.stop();
  }, clamp(Number(config.chunkSeconds), 2, 30) * 1000);
}

function enqueueAudio(blob, itemSequence, captureGeneration) {
  uploadQueue = uploadQueue
    .then(() => processAudio(blob, itemSequence, captureGeneration))
    .catch((error) => {
      if (!stopped && captureGeneration === generation) reportError(error.message);
    });
}

async function processAudio(blob, itemSequence, captureGeneration) {
  if (stopped || captureGeneration !== generation) return;
  const original = (await transcribe(blob)).trim();
  if (!original || stopped || captureGeneration !== generation) return;

  let translated = "";
  if (config.translationEnabled) {
    try {
      translated = (await translate(original)).trim();
    } catch (error) {
      reportError(`翻译失败，继续显示原文：${error.message}`);
    }
  }
  if (stopped || captureGeneration !== generation) return;

  chrome.runtime.sendMessage({
    target: "background",
    type: "CAPTION_RESULT",
    tabId: targetTabId,
    sequence: itemSequence,
    original,
    translated,
    display: {
      showOriginal: Boolean(config.showOriginal),
      fontSize: clamp(Number(config.fontSize), 14, 48),
      position: config.subtitlePosition === "top" ? "top" : "bottom",
      holdSeconds: Math.max(8, Number(config.chunkSeconds) * 2.5)
    }
  }).catch(() => {});
}

async function transcribe(blob) {
  const audio = await decodeToMono16k(blob);
  if (!audio.length || calculateRms(audio) < 0.004) return "";

  const options = { task: "transcribe" };
  if (config.sourceLanguage && config.sourceLanguage !== "auto") {
    options.language = config.sourceLanguage.trim();
  }
  const result = await transcriber(audio, options);
  return result?.text || "";
}

async function ensureTranscriber(captureGeneration) {
  const model = config.localTranscriptionModel.trim();
  const preference = config.localTranscriptionDevice || "auto";
  const canUseWebGpu = Boolean(navigator.gpu) && preference !== "wasm" && !webgpuFailedModels.has(model);
  const device = canUseWebGpu ? "webgpu" : "wasm";
  const key = `${model}:${device}`;
  if (transcriber && loadedModelKey === key) {
    inferenceDevice = device;
    return;
  }

  if (transcriber?.dispose) {
    try {
      await transcriber.dispose();
    } catch {
      // 某些后端不支持显式释放，旧实例会由浏览器回收。
    }
  }
  transcriber = null;
  loadedModelKey = "";

  let lastProgress = -1;
  const progressCallback = (event) => {
    if (stopped || captureGeneration !== generation || event?.status !== "progress") return;
    const progress = Math.floor(Number(event.progress) || 0);
    if (progress >= lastProgress + 5 || progress === 100) {
      lastProgress = progress;
      reportStatus("starting", `正在下载/加载本地模型：${progress}%`);
    }
  };

  try {
    const options = device === "webgpu"
      ? {
          device: "webgpu",
          dtype: { encoder_model: "fp32", decoder_model_merged: "q4" },
          progress_callback: progressCallback
        }
      : { device: "wasm", progress_callback: progressCallback };
    transcriber = await pipeline("automatic-speech-recognition", model, options);
    inferenceDevice = device;
    loadedModelKey = key;
  } catch (error) {
    if (device !== "webgpu") throw new Error(formatModelError(error));
    webgpuFailedModels.add(model);
    reportStatus("starting", "WebGPU 初始化失败，正在回退到 CPU/WASM…");
    try {
      transcriber = await pipeline("automatic-speech-recognition", model, {
        device: "wasm",
        progress_callback: progressCallback
      });
      inferenceDevice = "wasm";
      loadedModelKey = `${model}:wasm`;
    } catch (fallbackError) {
      throw new Error(formatModelError(fallbackError));
    }
  }
}

function formatModelError(error) {
  const message = error?.message || String(error);
  if (/fetch|network|connect|load failed/i.test(message)) {
    return `本地模型下载失败，请检查能否访问 huggingface.co：${message}`;
  }
  return `本地 Whisper 加载失败：${message}`;
}

async function decodeToMono16k(blob) {
  if (!audioContext) return new Float32Array();
  const decoded = await audioContext.decodeAudioData(await blob.arrayBuffer());
  const mono = new Float32Array(decoded.length);
  for (let channel = 0; channel < decoded.numberOfChannels; channel += 1) {
    const data = decoded.getChannelData(channel);
    for (let index = 0; index < data.length; index += 1) mono[index] += data[index] / decoded.numberOfChannels;
  }
  return resampleLinear(mono, decoded.sampleRate, 16000);
}

function resampleLinear(input, sourceRate, targetRate) {
  if (sourceRate === targetRate) return input;
  const length = Math.max(1, Math.round(input.length * targetRate / sourceRate));
  const output = new Float32Array(length);
  const ratio = sourceRate / targetRate;
  for (let index = 0; index < length; index += 1) {
    const position = index * ratio;
    const left = Math.floor(position);
    const right = Math.min(input.length - 1, left + 1);
    const weight = position - left;
    output[index] = input[left] * (1 - weight) + input[right] * weight;
  }
  return output;
}

function calculateRms(audio) {
  let sum = 0;
  for (let index = 0; index < audio.length; index += 1) sum += audio[index] * audio[index];
  return Math.sqrt(sum / audio.length);
}

async function translate(text) {
  const endpoint = config.translationEndpoint.trim() || joinUrl(config.translationBaseUrl, "chat/completions");
  const source = config.sourceLanguage === "auto" ? "自动识别的原语言" : config.sourceLanguage;
  const defaultPrompt = `你是专业的实时字幕翻译器。把${source}翻译成${config.targetLanguage}。只输出译文，不解释；保留人名、数字和语气；结合口语上下文修正断句。`;
  const systemPrompt = config.translationPrompt?.trim() || defaultPrompt;

  const body = {
    model: config.translationModel.trim(),
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: text }
    ],
    temperature: 0.2,
    stream: false
  };
  if (isDeepSeekEndpoint(endpoint)) body.thinking = { type: "disabled" };

  const response = await fetch(endpoint, {
    method: "POST",
    headers: buildHeaders("translation", true),
    body: JSON.stringify(body)
  });
  const data = await parseResponse(response, "翻译");
  return data.choices?.[0]?.message?.content || data.output_text || data.text || "";
}

function buildHeaders(_provider, json) {
  const headersValue = config.translationHeaders;
  const apiKey = config.translationApiKey;
  let extra = {};
  if (headersValue?.trim()) {
    try {
      extra = JSON.parse(headersValue);
    } catch {
      throw new Error("翻译请求头不是有效的 JSON");
    }
  }
  const headers = { ...extra };
  if (apiKey?.trim() && !headers.Authorization && !headers.authorization) {
    headers.Authorization = `Bearer ${apiKey.trim()}`;
  }
  if (json) headers["Content-Type"] = "application/json";
  return headers;
}

async function parseResponse(response, label) {
  const raw = await response.text();
  let data;
  try {
    data = raw ? JSON.parse(raw) : {};
  } catch {
    data = raw;
  }
  if (!response.ok) {
    const detail = typeof data === "string" ? data : data.error?.message || data.message || raw;
    throw new Error(`${label}接口 ${response.status}：${String(detail).slice(0, 300)}`);
  }
  return data;
}

function validateConfig(value) {
  if (!value.localTranscriptionModel?.trim()) throw new Error("请先选择本地转写模型");
  if (value.translationEnabled && !value.translationModel?.trim()) throw new Error("请先配置翻译模型");
  if (value.translationEnabled && !value.translationBaseUrl?.trim() && !value.translationEndpoint?.trim()) throw new Error("请先配置翻译 API 地址");
  if (value.translationEnabled) buildHeaders("translation", false);
}

function chooseMimeType() {
  return ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus"].find((type) => MediaRecorder.isTypeSupported(type)) || "";
}

function joinUrl(base, path) {
  return `${base.trim().replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}

function isDeepSeekEndpoint(endpoint) {
  try {
    return new URL(endpoint).hostname === "api.deepseek.com";
  } catch {
    return false;
  }
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
}

function reportStatus(status, message) {
  chrome.runtime.sendMessage({
    target: "background",
    type: "OFFSCREEN_STATUS",
    status,
    tabId: targetTabId,
    tabTitle: targetTabTitle,
    message
  }).catch(() => {});
}

function reportError(error) {
  chrome.runtime.sendMessage({
    target: "background",
    type: "CAPTION_ERROR",
    tabId: targetTabId,
    error
  }).catch(() => {});
}
