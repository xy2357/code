const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");
const statusMessage = document.getElementById("statusMessage");
const tabTitle = document.getElementById("tabTitle");
const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stopButton");
const optionsButton = document.getElementById("optionsButton");
const errorText = document.getElementById("errorText");

const labels = { idle: "未运行", starting: "正在启动", running: "字幕运行中", error: "出现错误" };

async function refresh() {
  const response = await chrome.runtime.sendMessage({ target: "background", type: "GET_STATE" });
  if (response?.state) render(response.state);
}

function render(state) {
  const active = ["starting", "running"].includes(state.status);
  statusDot.className = `dot ${state.status || "idle"}`;
  statusText.textContent = labels[state.status] || "未运行";
  statusMessage.textContent = state.message || "";
  tabTitle.textContent = state.tabTitle || "";
  tabTitle.hidden = !state.tabTitle;
  startButton.hidden = active;
  stopButton.hidden = !active;
  startButton.disabled = state.status === "starting";
  errorText.hidden = true;
}

function showError(message) {
  errorText.textContent = message;
  errorText.hidden = false;
}

startButton.addEventListener("click", async () => {
  startButton.disabled = true;
  errorText.hidden = true;
  const response = await chrome.runtime.sendMessage({ target: "background", type: "START_CAPTURE" });
  startButton.disabled = false;
  if (response?.state) render(response.state);
  if (!response?.ok) showError(response?.error || "启动失败");
});

stopButton.addEventListener("click", async () => {
  stopButton.disabled = true;
  const response = await chrome.runtime.sendMessage({ target: "background", type: "STOP_CAPTURE" });
  stopButton.disabled = false;
  if (response?.state) render(response.state);
  if (!response?.ok) showError(response?.error || "停止失败");
});

optionsButton.addEventListener("click", () => chrome.runtime.openOptionsPage());

chrome.runtime.onMessage.addListener((message) => {
  if (message?.target === "popup" && message.type === "STATE_CHANGED") render(message.state);
});

refresh().catch((error) => showError(error.message));
