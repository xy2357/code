const DEFAULTS = {
  localTranscriptionModel: "onnx-community/whisper-tiny",
  localTranscriptionDevice: "auto",
  translationBaseUrl: "https://api.deepseek.com",
  translationApiKey: "",
  translationEndpoint: "",
  translationHeaders: "{}",
  translationModel: "deepseek-v4-flash",
  sourceLanguage: "auto",
  targetLanguage: "简体中文",
  chunkSeconds: 10,
  translationEnabled: true,
  showOriginal: true,
  fontSize: 24,
  subtitlePosition: "bottom",
  translationPrompt: ""
};

const form = document.getElementById("settingsForm");
const status = document.getElementById("saveStatus");
const testButton = document.getElementById("testButton");
const deepseekPresetButton = document.getElementById("deepseekPresetButton");

const fields = Object.keys(DEFAULTS);

async function load() {
  const stored = await chrome.storage.local.get(null);
  const values = { ...DEFAULTS, ...stored };
  if (!("localTranscriptionModel" in stored) && stored.chunkSeconds === 5) values.chunkSeconds = 10;
  if (!("translationApiKey" in stored) && stored.apiKey) values.translationApiKey = stored.apiKey;
  if (!("translationHeaders" in stored) && stored.customHeaders) values.translationHeaders = stored.customHeaders;
  for (const key of fields) {
    const element = document.getElementById(key);
    if (!element) continue;
    if (element.type === "checkbox") element.checked = Boolean(values[key]);
    else element.value = values[key] ?? "";
  }
}

function collect() {
  const values = {};
  for (const key of fields) {
    const element = document.getElementById(key);
    if (!element) continue;
    if (element.type === "checkbox") values[key] = element.checked;
    else if (element.type === "number") values[key] = Number(element.value);
    else values[key] = element.value.trim();
  }
  JSON.parse(values.translationHeaders || "{}");
  return values;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const values = collect();
    await chrome.storage.local.set(values);
    setStatus("设置已保存", false);
  } catch (error) {
    setStatus(`保存失败：${error.message}`, true);
  }
});

testButton.addEventListener("click", async () => {
  testButton.disabled = true;
  setStatus("正在测试，会产生一次很小的模型请求…", false);
  try {
    const values = collect();
    const endpoint = values.translationEndpoint || `${values.translationBaseUrl.replace(/\/+$/, "")}/chat/completions`;
    const extraHeaders = JSON.parse(values.translationHeaders || "{}");
    const headers = { ...extraHeaders, "Content-Type": "application/json" };
    if (values.translationApiKey && !headers.Authorization && !headers.authorization) headers.Authorization = `Bearer ${values.translationApiKey}`;
    const body = {
      model: values.translationModel,
      messages: [
        { role: "system", content: `把用户文本翻译为${values.targetLanguage}，只输出译文。` },
        { role: "user", content: "Hello" }
      ],
      temperature: 0,
      stream: false
    };
    if (new URL(endpoint).hostname === "api.deepseek.com") body.thinking = { type: "disabled" };
    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    });
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = raw; }
    if (!response.ok) throw new Error(`${response.status} ${typeof data === "string" ? data : data.error?.message || raw}`);
    const answer = data.choices?.[0]?.message?.content || data.output_text || data.text;
    if (!answer) throw new Error("接口成功响应，但没有找到译文内容");
    setStatus(`连接成功：${String(answer).slice(0, 80)}`, false);
  } catch (error) {
    setStatus(`测试失败：${error.message}`, true);
  } finally {
    testButton.disabled = false;
  }
});

deepseekPresetButton.addEventListener("click", () => {
  document.getElementById("translationBaseUrl").value = "https://api.deepseek.com";
  document.getElementById("translationEndpoint").value = "";
  document.getElementById("translationModel").value = "deepseek-v4-flash";
  document.getElementById("translationHeaders").value = "{}";
  setStatus("已填入 DeepSeek 翻译预设，请输入 DeepSeek API Key 后保存或测试", false);
});

function setStatus(message, isError) {
  status.textContent = message;
  status.style.color = isError ? "#b12a3c" : "#2b7f57";
}

load().catch((error) => setStatus(`读取设置失败：${error.message}`, true));
