const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
const STATE_KEY = "runtimeState";

const CONFIG_DEFAULTS = {
  localTranscriptionModel: "onnx-community/whisper-tiny",
  localTranscriptionDevice: "auto",
  translationBaseUrl: "https://api.deepseek.com",
  translationApiKey: "",
  translationEndpoint: "",
  translationHeaders: "{}",
  translationModel: "deepseek-v4-flash",
  sourceLanguage: "auto",
  targetLanguage: "简体中文",
  chunkSeconds: 10,
  translationEnabled: true,
  showOriginal: true,
  fontSize: 24,
  subtitlePosition: "bottom",
  translationPrompt: ""
};

const idleState = {
  status: "idle",
  tabId: null,
  tabTitle: "",
  message: "尚未开始"
};

async function getState() {
  const result = await chrome.storage.session.get(STATE_KEY);
  return result[STATE_KEY] || idleState;
}

async function setState(patch) {
  const next = { ...(await getState()), ...patch };
  await chrome.storage.session.set({ [STATE_KEY]: next });
  chrome.runtime.sendMessage({ target: "popup", type: "STATE_CHANGED", state: next }).catch(() => {});
  return next;
}

async function ensureOffscreenDocument() {
  if (await chrome.offscreen.hasDocument()) return;

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ["USER_MEDIA"],
    justification: "捕获当前标签页音频，并将音频分片发送到用户配置的转写接口"
  });
}

async function sendToOffscreen(message) {
  await ensureOffscreenDocument();
  return chrome.runtime.sendMessage({ target: "offscreen", ...message });
}

async function startCapture() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !/^https?:/.test(tab.url || "")) {
    throw new Error("请在普通 http/https 网页的视频标签页中启动字幕。浏览器内部页面不支持捕获。");
  }

  const previous = await getState();
  if (["starting", "running"].includes(previous.status)) {
    await sendToOffscreen({ type: "STOP_CAPTURE" }).catch(() => {});
  }

  await setState({
    status: "starting",
    tabId: tab.id,
    tabTitle: tab.title || "当前标签页",
    message: "正在连接标签页音频…"
  });

  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
  const captureConfig = await loadCaptureConfig();
  const response = await sendToOffscreen({
    type: "START_CAPTURE",
    streamId,
    tabId: tab.id,
    tabTitle: tab.title || "当前标签页",
    config: captureConfig
  });

  if (!response?.ok) throw new Error(response?.error || "音频捕获启动失败");
  return getState();
}

async function loadCaptureConfig() {
  const stored = await chrome.storage.local.get(null);
  const migrated = { ...CONFIG_DEFAULTS, ...stored };
  const isLegacyConfig = !("localTranscriptionModel" in stored);
  if (isLegacyConfig && stored.chunkSeconds === 5) migrated.chunkSeconds = 10;

  // 兼容 0.1.x 的翻译接口设置。
  if (!("translationApiKey" in stored) && stored.apiKey) migrated.translationApiKey = stored.apiKey;
  if (!("translationHeaders" in stored) && stored.customHeaders) migrated.translationHeaders = stored.customHeaders;

  return migrated;
}

async function stopCapture() {
  const state = await getState();
  if (state.tabId) {
    chrome.tabs.sendMessage(state.tabId, { type: "CAPTION_STATUS", status: "stopped" }).catch(() => {});
  }
  await sendToOffscreen({ type: "STOP_CAPTURE" }).catch(() => {});
  return setState({ ...idleState, message: "已停止" });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target && message.target !== "background") return false;

  if (message?.type === "GET_STATE") {
    getState().then((state) => sendResponse({ ok: true, state }));
    return true;
  }

  if (message?.type === "START_CAPTURE") {
    startCapture()
      .then((state) => sendResponse({ ok: true, state }))
      .catch(async (error) => {
        const state = await setState({ ...idleState, status: "error", message: error.message });
        sendResponse({ ok: false, error: error.message, state });
      });
    return true;
  }

  if (message?.type === "STOP_CAPTURE") {
    stopCapture()
      .then((state) => sendResponse({ ok: true, state }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "OFFSCREEN_STATUS") {
    setState({
      status: message.status,
      tabId: message.tabId ?? null,
      tabTitle: message.tabTitle ?? "",
      message: message.message || ""
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message?.type === "CAPTION_RESULT" && Number.isInteger(message.tabId)) {
    chrome.tabs.sendMessage(message.tabId, {
      type: "CAPTION_RESULT",
      original: message.original,
      translated: message.translated,
      sequence: message.sequence,
      display: message.display
    }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "CAPTION_ERROR" && Number.isInteger(message.tabId)) {
    chrome.tabs.sendMessage(message.tabId, {
      type: "CAPTION_ERROR",
      error: message.error
    }).catch(() => {});
    setState({ status: "running", message: `接口错误：${message.error}` }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (state.tabId === tabId && ["starting", "running"].includes(state.status)) {
    await stopCapture();
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.session.get(STATE_KEY);
  if (!existing[STATE_KEY]) await chrome.storage.session.set({ [STATE_KEY]: idleState });
});
