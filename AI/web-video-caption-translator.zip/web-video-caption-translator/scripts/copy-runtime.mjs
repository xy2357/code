import { cp, mkdir, readdir } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = join(root, "node_modules", "onnxruntime-web", "dist");
const destination = join(root, "vendor");

await mkdir(destination, { recursive: true });
for (const file of await readdir(source)) {
  if (/\.wasm$/.test(file)) await cp(join(source, file), join(destination, file));
}
