const HOST_ID = "__live_caption_translator_host__";
let host = null;
let originalLine = null;
let translatedLine = null;
let noticeLine = null;
let hideTimer = null;

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "CAPTION_RESULT") showCaption(message);
  if (message?.type === "CAPTION_ERROR") showNotice(`字幕接口错误：${message.error}`, true);
  if (message?.type === "CAPTION_STATUS" && message.status === "stopped") hideCaption();
});

document.addEventListener("fullscreenchange", () => {
  if (host?.isConnected) mountOverlay();
});

function ensureOverlay() {
  if (host?.isConnected) return;

  document.getElementById(HOST_ID)?.remove();
  host = document.createElement("div");
  host.id = HOST_ID;
  host.style.cssText = "all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;";
  const shadow = host.attachShadow({ mode: "closed" });

  const style = document.createElement("style");
  style.textContent = `
    .wrap { position: fixed; left: 50%; width: min(92vw, 1100px); transform: translateX(-50%); text-align: center; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif; transition: opacity .18s ease; }
    .wrap.bottom { bottom: 9vh; }
    .wrap.top { top: 7vh; }
    .line { display: table; max-width: 100%; margin: 5px auto; padding: .18em .55em; border-radius: .35em; color: #fff; background: rgba(0,0,0,.76); box-decoration-break: clone; -webkit-box-decoration-break: clone; line-height: 1.4; text-shadow: 0 1px 2px #000; overflow-wrap: anywhere; }
    .translated { font-weight: 650; }
    .original { font-size: .76em; color: #e9edf4; }
    .notice { display: none; font-size: 14px; color: #fff; background: rgba(165, 34, 34, .92); }
  `;

  const wrap = document.createElement("div");
  wrap.className = "wrap bottom";
  translatedLine = document.createElement("div");
  translatedLine.className = "line translated";
  originalLine = document.createElement("div");
  originalLine.className = "line original";
  noticeLine = document.createElement("div");
  noticeLine.className = "line notice";
  wrap.append(translatedLine, originalLine, noticeLine);
  shadow.append(style, wrap);
  mountOverlay();
  host._captionWrap = wrap;
}

function mountOverlay() {
  const fullscreenRoot = document.fullscreenElement;
  const canContainOverlay = fullscreenRoot && !["VIDEO", "IFRAME"].includes(fullscreenRoot.tagName);
  (canContainOverlay ? fullscreenRoot : document.documentElement).append(host);
}

function showCaption(message) {
  ensureOverlay();
  const display = message.display || {};
  const wrap = host._captionWrap;
  wrap.className = `wrap ${display.position === "top" ? "top" : "bottom"}`;
  wrap.style.fontSize = `${Math.min(48, Math.max(14, Number(display.fontSize) || 24))}px`;
  wrap.style.opacity = "1";

  translatedLine.textContent = message.translated || (display.showOriginal ? "" : message.original);
  translatedLine.style.display = translatedLine.textContent ? "table" : "none";
  originalLine.textContent = message.original || "";
  originalLine.style.display = display.showOriginal && originalLine.textContent ? "table" : "none";
  noticeLine.style.display = "none";

  clearTimeout(hideTimer);
  hideTimer = setTimeout(hideCaption, (Number(display.holdSeconds) || 10) * 1000);
}

function showNotice(text, isError = false) {
  ensureOverlay();
  noticeLine.textContent = text;
  noticeLine.style.display = "table";
  noticeLine.style.background = isError ? "rgba(165, 34, 34, .92)" : "rgba(0, 0, 0, .76)";
  clearTimeout(hideTimer);
  hideTimer = setTimeout(hideCaption, 8000);
}

function hideCaption() {
  if (host?._captionWrap) host._captionWrap.style.opacity = "0";
}
