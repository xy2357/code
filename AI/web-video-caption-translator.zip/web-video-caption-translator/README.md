# 网页视频实时字幕与翻译

一个可直接加载到 Chrome / Edge 的 Manifest V3 扩展。它捕获当前标签页音频，用浏览器本地 Whisper 转写，再将文字发送到可选的翻译 API，并把双语字幕叠加在网页上。音频不会上传，转写不需要 API Key。

## 安装

1. 打开 `chrome://extensions`（Edge 使用 `edge://extensions`）。
2. 开启右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本项目文件夹 `web-video-caption-translator`。
5. 点击扩展图标，进入“API 与字幕设置”，选择本地模型并填写可选的翻译接口。
6. 如果目标视频网页在安装扩展前已经打开，请刷新一次该网页。

## 使用

1. 打开普通的 `http/https` 视频网页并开始播放。
2. 点击扩展图标，再点击“开始字幕”。
3. 字幕会以固定浮层显示在网页顶部或底部。
4. 用完后点击“停止”。

首次启动字幕时会从 Hugging Face 下载 Whisper 模型，模型为百 MB 级，下载进度会显示在扩展弹窗中。下载完成后浏览器会缓存模型。首次使用也建议在设置页点击“测试翻译接口”；该按钮只测试文本翻译。

## 本地转写

扩展提供三个多语言模型选项：

- `Whisper Tiny`：推荐默认值，下载较小、速度最快，准确率一般。
- `Whisper Base`：准确率与资源占用较平衡。
- `Whisper Small`：更准确，但下载、内存和计算开销明显更大。

默认优先使用 WebGPU；设备或驱动不支持时会自动回退到 CPU/WASM。源语言填写 `auto` 时由 Whisper 自动识别。不要选择名称以 `.en` 结尾的模型，否则只能识别英语。

## DeepSeek 翻译配置

点击“使用 DeepSeek 预设”，然后填写 DeepSeek API Key。预设值为：

- Base URL：`https://api.deepseek.com`
- 模型：`deepseek-v4-flash`
- 完整请求地址：`https://api.deepseek.com/chat/completions`

不需要翻译时，可以关闭“启用翻译”，此时音频和文字均不会发送到任何模型 API。

## API 兼容格式

翻译服务按 OpenAI 兼容协议调用 `POST {Base URL}/chat/completions`，响应需要包含 `choices[0].message.content`，默认使用 `Authorization: Bearer <API Key>`。

如果服务商路径或鉴权不同，可以填写完整 URL，并用“额外请求头（JSON）”添加请求头。

## 延迟与费用

- 这不是逐音频帧流式协议，而是“短分片准实时”方案。默认每 10 秒处理一次，实际延迟取决于分片时长、电脑性能和翻译接口响应时间。
- 把分片调短会降低等待时间，但也可能降低转写上下文完整性；性能较弱的电脑可能来不及处理。
- 翻译请求按分片逐段进行，当前版本不会把整场视频历史持续发送给模型。

## 隐私与限制

- 翻译 API Key 保存在浏览器的 `chrome.storage.local` 中，但它不是系统级加密保险箱。不要在不可信设备上保存高权限 Key。
- 视频音频仅在浏览器本地转写；开启翻译后，转写文字会发送到你配置的翻译服务。
- 浏览器内部页面（如 `chrome://`）、Chrome Web Store 页面及部分受保护/DRM 内容无法捕获或注入字幕。
- 常见网站的播放器容器全屏模式可以显示字幕；如果网站直接让原生 `<video>` 元素全屏，浏览器可能会隐藏扩展浮层。
- 无声页面、被系统静音的来源，或某些特殊播放器可能没有可用音轨。
- 需要 Chrome / Edge 116 或更高版本。

## 项目文件

- `background.js`：管理标签页捕获与消息路由。
- `offscreen.js`：录音分片、本地 Whisper 转写和翻译请求的源代码。
- `offscreen.bundle.js`：包含 Transformers.js 的浏览器运行包。
- `vendor/`：本地 ONNX Runtime WASM 文件。
- `content.js`：网页字幕浮层。
- `popup.*`：开始/停止控制。
- `options.*`：接口、模型、语言和字幕设置。

## 开发

修改 `offscreen.js` 后需要执行：

```powershell
npm install
npm run build
```

其他文件修改后可直接在扩展管理页点击“重新加载”。
